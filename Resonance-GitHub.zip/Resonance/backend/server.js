
const express = require("express");
const db = require("./db");

const app = express();
app.use(express.json());

// Consultar usuários
app.get("/api/users", (req, res) => {
  try {
    const users = db.prepare(`
      SELECT id_usuario, nome_exibicao, email,
             data_cadastro, ativo
      FROM usuario
      ORDER BY id_usuario DESC
    `).all();

    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      erro: "Não foi possível consultar os usuários."
    });
  }
});

// Cadastrar usuário
app.post("/api/users", (req, res) => {
  const { nome_exibicao, email } = req.body;

  if (
    typeof nome_exibicao !== "string" ||
    typeof email !== "string" ||
    !nome_exibicao.trim() ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) ||
    nome_exibicao.trim().length > 60 ||
    email.trim().length > 120
  ) {
    return res.status(400).json({
      erro: "Informe um nome e um e-mail válidos."
    });
  }

  try {
    const result = db.prepare(`
      INSERT INTO usuario (nome_exibicao, email)
      VALUES (?, ?)
    `).run(nome_exibicao.trim(), email.trim());

    res.status(201).json({
      mensagem: "Usuário cadastrado!",
      id_usuario: Number(result.lastInsertRowid)
    });
  } catch (error) {
    if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
      return res.status(409).json({
        erro: "Este e-mail já está cadastrado."
      });
    }

    console.error(error);
    res.status(500).json({
      erro: "Não foi possível cadastrar o usuário."
    });
  }
});

const port = Number(process.env.PORT || 3000);

app.listen(port, () => {
  console.log(`API Resonance disponível em http://localhost:${port}`);
});
