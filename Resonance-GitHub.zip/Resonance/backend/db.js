
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");
require("dotenv").config({
  path: path.join(__dirname, "..", ".env")
});

const dbPath = process.env.DB_PATH;

if (!dbPath) {
  throw new Error(
    "DB_PATH não foi configurado no arquivo .env"
  );
}

if (!fs.existsSync(dbPath)) {
  throw new Error(
    `Banco SQLite não encontrado: ${dbPath}`
  );
}

const db = new Database(dbPath);

db.pragma("foreign_keys = ON");

module.exports = db;
